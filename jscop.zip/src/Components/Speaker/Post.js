import React from 'react'
import './Post.css';

function Post() {
  return (
   <></>
  )
}

export default Post