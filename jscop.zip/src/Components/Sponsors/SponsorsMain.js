import React from 'react'
import './SponsorsMain.css'

function SponsorsMain() {
  return (
    <div className="SponsorsMain">
    <div class="scrollbox scrollbox--primary">
  <div class="scrollbox__item"><img src="adidas.png" alt="" /></div>
  <div class="scrollbox__item"><img src="facebook.png" alt="logo"/></div>
  <div class="scrollbox__item"><img src="google.png" alt="" /></div>
  <div class="scrollbox__item"><img src="instagram.png" alt="" /></div>
  <div class="scrollbox__item"><img src="instagram.png" alt="" /></div>
  <div class="scrollbox__item"><img src="instagram.png" alt="" /></div>
  <div class="scrollbox__item"><img src="instagram.png" alt="" /></div>
  <div class="scrollbox__item"><img src="instagram.png" alt="" /></div>
  <div class="scrollbox__item"><img src="instagram.png" alt="" /></div>
  <div class="scrollbox__item"><img src="instagram.png" alt="" /></div>
  <div class="scrollbox__item"><img src="instagram.png" alt="" /></div>
  <div class="scrollbox__item"><img src="instagram.png" alt="" /></div>
  <div class="scrollbox__item"><img src="instagram.png" alt="" /></div>
  <div class="scrollbox__item"><img src="instagram.png" alt="" /></div>
  <div class="scrollbox__item"><img src="instagram.png" alt="" /></div>
  <div class="scrollbox__item"><img src="instagram.png" alt="" /></div>
  <div class="scrollbox__item"><img src="instagram.png" alt="" /></div>
  <div class="scrollbox__item"><img src="instagram.png" alt="" /></div>
  <div class="scrollbox__item"><img src="instagram.png" alt="" /></div>
  <div class="scrollbox__item"><img src="instagram.png" alt="" /></div>
  <div class="scrollbox__item"><img src="instagram.png" alt="" /></div>
  <div class="scrollbox__item"><img src="instagram.png" alt="" /></div>
  <div class="scrollbox__item"><img src="instagram.png" alt="" /></div>
  <div class="scrollbox__item"><img src="instagram.png" alt="" /></div>
  <div class="scrollbox__item"><img src="instagram.png" alt="" /></div>
  <div class="scrollbox__item"><img src="instagram.png" alt="" /></div>
  <div class="scrollbox__item"><img src="instagram.png" alt="" /></div>
  <div class="scrollbox__item"><img src="instagram.png" alt="" /></div>
  <div class="scrollbox__item"><img src="instagram.png" alt="" /></div>
  <div class="scrollbox__item"><img src="instagram.png" alt="" /></div>
  <div class="scrollbox__item"><img src="instagram.png" alt="" /></div>
  <div class="scrollbox__item"><img src="instagram.png" alt="" /></div>
  <div class="scrollbox__item"><img src="instagram.png" alt="" /></div>
  <div class="scrollbox__item"><img src="instagram.png" alt="" /></div>
  <div class="scrollbox__item"><img src="instagram.png" alt="" /></div>
  <div class="scrollbox__item"><img src="instagram.png" alt="" /></div>
  <div class="scrollbox__item"><img src="instagram.png" alt="" /></div>
  <div class="scrollbox__item"><img src="instagram.png" alt="" /></div>
  <div class="scrollbox__item"><img src="instagram.png" alt="" /></div>
  <div class="scrollbox__item"><img src="instagram.png" alt="" /></div>
  <div class="scrollbox__item"><img src="nike.png" alt="" /></div>
</div>

<div class="scrollbox scrollbox--secondary scrollbox--reverse">
<div class="scrollbox__item"><img src="adidas.png" alt="" /></div>
  <div class="scrollbox__item"><img src="facebook.png" alt="logo"/></div>
  <div class="scrollbox__item"><img src="facebook.png" alt="logo"/></div>
  <div class="scrollbox__item"><img src="facebook.png" alt="logo"/></div>
  <div class="scrollbox__item"><img src="facebook.png" alt="logo"/></div>
  <div class="scrollbox__item"><img src="facebook.png" alt="logo"/></div>
  <div class="scrollbox__item"><img src="facebook.png" alt="logo"/></div>
  <div class="scrollbox__item"><img src="facebook.png" alt="logo"/></div>
  <div class="scrollbox__item"><img src="facebook.png" alt="logo"/></div>
  <div class="scrollbox__item"><img src="facebook.png" alt="logo"/></div>
  <div class="scrollbox__item"><img src="facebook.png" alt="logo"/></div>
  <div class="scrollbox__item"><img src="facebook.png" alt="logo"/></div>
  <div class="scrollbox__item"><img src="facebook.png" alt="logo"/></div>
  <div class="scrollbox__item"><img src="facebook.png" alt="logo"/></div>
  <div class="scrollbox__item"><img src="facebook.png" alt="logo"/></div>
  <div class="scrollbox__item"><img src="facebook.png" alt="logo"/></div>
  <div class="scrollbox__item"><img src="facebook.png" alt="logo"/></div>
  <div class="scrollbox__item"><img src="facebook.png" alt="logo"/></div>
  <div class="scrollbox__item"><img src="facebook.png" alt="logo"/></div>
  <div class="scrollbox__item"><img src="facebook.png" alt="logo"/></div>
  <div class="scrollbox__item"><img src="facebook.png" alt="logo"/></div>
  <div class="scrollbox__item"><img src="facebook.png" alt="logo"/></div>
  <div class="scrollbox__item"><img src="facebook.png" alt="logo"/></div>
  <div class="scrollbox__item"><img src="facebook.png" alt="logo"/></div>
  <div class="scrollbox__item"><img src="facebook.png" alt="logo"/></div>
  <div class="scrollbox__item"><img src="facebook.png" alt="logo"/></div>
  <div class="scrollbox__item"><img src="facebook.png" alt="logo"/></div>
  <div class="scrollbox__item"><img src="facebook.png" alt="logo"/></div>
  <div class="scrollbox__item"><img src="google.png" alt="" /></div>
  <div class="scrollbox__item"><img src="instagram.png" alt="" /></div>
  <div class="scrollbox__item"><img src="nike.png" alt="" /></div>
</div>

    </div>
  )
}

export default SponsorsMain